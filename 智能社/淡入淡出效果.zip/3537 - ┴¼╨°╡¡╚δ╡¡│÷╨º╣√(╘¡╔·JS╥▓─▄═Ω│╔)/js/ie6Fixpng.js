// JavaScript Document
DD_belatedPNG.fix('div');
DD_belatedPNG.fix('a');
